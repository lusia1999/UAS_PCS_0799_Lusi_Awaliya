package id.lusia0799.githubuser.data.model

data class UserResponse(
    val items : ArrayList<User>
)