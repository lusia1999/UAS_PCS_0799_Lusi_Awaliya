package id.lusia0799.githubuser.data.model

data class User(
    val login: String,
    val avatar_url: String
)
